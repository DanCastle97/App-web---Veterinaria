<?php
// Iniciar sesión y conectar a la base de datos
session_start();
require 'conexion.php'; // Incluye tu archivo de conexión a la base de datos

// Verificar que se haya enviado un ID de cliente
if (isset($_POST['id_cliente'])) {
    $id_cliente = $_POST['id_cliente'];

    // Preparar la consulta para eliminar el cliente
    $stmt = $conn->prepare("DELETE FROM clientes WHERE id_cliente = ?");
    $stmt->bind_param("s", $id_cliente);

    // Ejecutar la consulta
    if ($stmt->execute()) {
        echo "Cliente eliminado"; // Mensaje de éxito
    } else {
        echo "Error al eliminar el cliente: " . $stmt->error; // Mensaje de error
    }

    // Cerrar la declaración y la conexión
    $stmt->close();
    $conn->close();
} else {
    echo "ID de cliente no proporcionado";
}
?>
