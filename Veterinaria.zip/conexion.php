<?php
$servername = "127.0.0.1:3306";
$username = "u485633635_Loovic";  // Cambia esto si tu usuario de base de datos es diferente
$password = "Loovic#24";      // Cambia esto si tu contraseña es diferente
$dbname = "u485633635_Vet";  // Cambia esto al nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
