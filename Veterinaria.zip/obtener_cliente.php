<?php
require 'conexion.php';

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el id_cliente de la solicitud GET
$id_cliente = isset($_GET['id_cliente']) ? intval($_GET['id_cliente']) : 0;

// Depurar el id_cliente recibido
error_log("ID Cliente recibido: " . $id_cliente);

// Preparar la consulta SQL
$sql = "SELECT id_cliente, nombre, apellidos, direccion, telefono, RFC, codigo_postal, num_cuenta, contactos_extra, mascotas
        FROM clientes
        WHERE id_cliente = ?";

// Preparar y ejecutar la consulta
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_cliente);
$stmt->execute();

// Obtener el resultado
$result = $stmt->get_result();
$data = $result->fetch_assoc();

// Depurar los datos obtenidos
error_log("Datos obtenidos: " . print_r($data, true));

// Devolver los datos en formato JSON
header('Content-Type: application/json');
echo json_encode($data);

// Cerrar la conexión
$stmt->close();
$conn->close();
?>
