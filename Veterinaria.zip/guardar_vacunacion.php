<?php
require 'conexion.php'; // Incluye el archivo de conexión

header('Content-Type: application/json');

// Obtener los datos del formulario
$id_paciente = $_POST['id_paciente'];
$especie = $_POST['especie'];
$fecha_vacunacion = $_POST['fecha_vacunacion'];
$enfermedad_vacuna = $_POST['enfermedad_vacuna'];
$vacuna = $_POST['vacuna']; // Nuevo campo

// Verificar si el ID del paciente existe en la tabla 'pacientes'
$sql = "SELECT id_paciente FROM pacientes WHERE id_paciente = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id_paciente);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['status' => 'error', 'message' => 'El ID del paciente no existe en la base de datos.']);
    exit();
}

// Inserción en la tabla
$sql = "INSERT INTO calendario_vacunacion (id_paciente, especie, fecha_vacunacion, enfermedad_vacuna, vacuna) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(['status' => 'error', 'message' => 'Error en la preparación de la consulta: ' . $conn->error]);
    exit();
}

$stmt->bind_param("sssss", $id_paciente, $especie, $fecha_vacunacion, $enfermedad_vacuna, $vacuna);

if ($stmt->execute()) {
    // Obtener el ID generado automáticamente
    $id_vacuna = $conn->insert_id;
    echo json_encode(['status' => 'success', 'message' => 'Guardado exitosamente.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
