<?php
// Incluir el archivo de conexión
require 'conexion.php';

if (isset($_POST['id'])) {
    $id = intval($_POST['id']);
    
    // Preparar y ejecutar la consulta de eliminación
    $stmt = $conn->prepare("DELETE FROM pacientes WHERE id_paciente = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        echo json_encode(array('status' => 'success'));
    } else {
        echo json_encode(array('status' => 'error'));
    }
    
    $stmt->close();
}

$conn->close();
?>
