<?php
// Incluir el archivo de conexión
require 'conexion.php';

// Verifica si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $alias = $_POST['alias'];
    $especie = $_POST['especie'];
    $raza = $_POST['raza'];
    $color_pelo = $_POST['color_pelo'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $peso_medio = $_POST['peso_medio'];
    $peso_actual = $_POST['peso_actual'];
    $id_cliente = $_POST['id_cliente']; // ID del cliente seleccionado

    // Procesar la foto
    $foto = $_FILES['foto']['name'];
    $fotoTmpName = $_FILES['foto']['tmp_name'];
    $fotoSize = $_FILES['foto']['size'];
    $fotoError = $_FILES['foto']['error'];
    $fotoType = $_FILES['foto']['type'];

    if ($fotoError === 0) {
        // Generar un nombre único para la imagen
        $fotoNameNew = uniqid('', true) . "." . pathinfo($foto, PATHINFO_EXTENSION);
        $fotoDestination = 'imagen_mascotas/' . $fotoNameNew;

        // Mover la imagen a la carpeta 'imagen_mascotas'
        if (move_uploaded_file($fotoTmpName, $fotoDestination)) {
            // Preparar la consulta SQL para insertar los datos
            $sql = "INSERT INTO pacientes (alias, especie, raza, color_pelo, fecha_nacimiento, peso_medio, peso_actual, id_cliente, foto) 
                    VALUES ('$alias', '$especie', '$raza', '$color_pelo', '$fecha_nacimiento', '$peso_medio', '$peso_actual', '$id_cliente', '$fotoNameNew')";

            if ($conn->query($sql) === TRUE) {
                // Redirigir con un parámetro para mostrar la alerta de éxito en mascotas.php
                header("Location: mascotas.php?status=success");
                exit(); // Asegúrate de que no se ejecute más código después de la redirección
            } else {
                // Redirigir con un parámetro de error
                header("Location: mascotas.php?status=error&message=Error%20al%20insertar%20los%20datos%20en%20la%20base%20de%20datos.");
                exit();
            }
        } else {
            // Redirigir con un parámetro de error
            header("Location: mascotas.php?status=error&message=Error%20al%20mover%20el%20archivo%20de%20imagen.");
            exit();
        }
    } else {
        // Redirigir con un parámetro de error
        header("Location: mascotas.php?status=error&message=Error%20en%20el%20archivo%20de%20imagen.");
        exit();
    }
}

// Cerrar la conexión
$conn->close();
?>
