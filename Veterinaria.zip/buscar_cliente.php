<?php
require 'conexion.php';

if (isset($_GET['nombre'])) {
    $nombre = $conn->real_escape_string($_GET['nombre']);
    
    $sql = "SELECT id_cliente FROM clientes WHERE nombre LIKE '%$nombre%'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $cliente = $result->fetch_assoc();
        echo json_encode(['id_cliente' => $cliente['id_cliente']]);
    } else {
        echo json_encode(['id_cliente' => null]);
    }
    
    $conn->close();
} else {
    echo json_encode(['id_cliente' => null]);
}
?>
