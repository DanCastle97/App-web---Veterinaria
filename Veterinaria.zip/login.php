<?php
session_start();
include('conexion.php');

$usuario = $_POST['usuario'];
$password = $_POST['password'];

// Escapar las entradas para evitar inyección SQL
$usuario = mysqli_real_escape_string($conn, $usuario);
$password = mysqli_real_escape_string($conn, $password);

// Consulta para obtener el usuario
$consulta = "SELECT * FROM usuarios WHERE usuario='$usuario' AND password='$password'";
$resultado = mysqli_query($conn, $consulta);

$filas = mysqli_num_rows($resultado);

if ($filas) {
    // Iniciar sesión
    $_SESSION["usuario"] = $usuario;
    // Redirigir con parámetro de éxito
    header("Location: inicio.php?success=true");
    exit();
} else {
    // Redirigir con parámetro de error
    header("Location: index.php?error=true");
    exit();
}

// Liberar recursos y cerrar la conexión
mysqli_free_result($resultado);
mysqli_close($conn);
?>
