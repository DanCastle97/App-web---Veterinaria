<?php
// Incluir el archivo de conexión a la base de datos
include 'conexion.php';

// Obtener los datos del formulario
$id_cliente = isset($_POST['id_cliente']) ? $conn->real_escape_string($_POST['id_cliente']) : ''; // Cambiado a string
$nombre = isset($_POST['nombre']) ? $conn->real_escape_string($_POST['nombre']) : '';
$apellidos = isset($_POST['apellidos']) ? $conn->real_escape_string($_POST['apellidos']) : '';
$direccion = isset($_POST['direccion']) ? $conn->real_escape_string($_POST['direccion']) : '';
$telefono = isset($_POST['telefono']) ? $conn->real_escape_string($_POST['telefono']) : '';
$RFC = isset($_POST['RFC']) ? $conn->real_escape_string($_POST['RFC']) : '';
$codigo_postal = isset($_POST['codigo_postal']) ? $conn->real_escape_string($_POST['codigo_postal']) : '';
$num_cuenta = isset($_POST['num_cuenta']) ? $conn->real_escape_string($_POST['num_cuenta']) : '';
$contactos_extra = isset($_POST['contactos_extra']) ? $conn->real_escape_string($_POST['contactos_extra']) : '';
$mascotas = isset($_POST['mascotas']) ? intval($_POST['mascotas']) : 0; // Asegúrate de que este campo sea un número

// Preparar la consulta SQL para actualizar el cliente
$sql = "UPDATE clientes
        SET nombre = ?, apellidos = ?, direccion = ?, telefono = ?, RFC = ?, codigo_postal = ?, num_cuenta = ?, contactos_extra = ?, mascotas = ?
        WHERE id_cliente = ?";

// Preparar y ejecutar la consulta
$stmt = $conn->prepare($sql);

// Verificar si la preparación de la consulta fue exitosa
if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
}

// Vincular los parámetros
$stmt->bind_param("ssssssssis", $nombre, $apellidos, $direccion, $telefono, $RFC, $codigo_postal, $num_cuenta, $contactos_extra, $mascotas, $id_cliente); // Cambiado el tipo de id_cliente a string

if ($stmt->execute()) {
    echo "actualizado"; // Mensaje de éxito
} else {
    echo "error: " . $stmt->error; // Mensaje de error detallado
}

// Cerrar la conexión
$stmt->close();
$conn->close();
?>
