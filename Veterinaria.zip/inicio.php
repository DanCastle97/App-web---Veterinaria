<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION["usuario"])) {
    // Redirige al usuario a la página de inicio de sesión si no está autenticado
    header("Location: index.php");
    exit();
}

// El resto del contenido de la página inicio.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Veterinaria</title>
  <!-- ======= Styles ====== -->
  <link rel="stylesheet" href="assets/css/style.css" />
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" />
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
  
</head>

<body>
  <!-- =============== Navigation ================ -->
  <div class="container">
    <div class="navigation">
      <ul>
        <li>
          <a href="#">
            <span class="icon">
              <img
                src="./assets/imgs/perro.png"
                alt="Mr.Firulays"
                style="width: 60px; height: 60px; padding-top: 6px"
              />
            </span>
            <span class="title"><span class="red">Mr</span>
              <span class="orange">.</span>
              <span class="blue">Firu</span>
              <span class="yellow">lays</span>
              <span class="green"></span>
              <span class="pink"></span></span>
          </a>
        </li>
      
        <li>
          <a href="./inicio.php">
            <span class="icon">
              <ion-icon name="home-outline"></ion-icon>
            </span>
            <span class="title">Inicio</span>
          </a>
        </li>

        <li>
          <a href="clientes.php">
            <span class="icon">
              <ion-icon name="people-outline"></ion-icon>
            </span>
            <span class="title">Clientes</span>
          </a>
        </li>

        <li>
          <a href="mascotas.php">
            <span class="icon">
              <ion-icon name="paw-outline"></ion-icon>
            </span>
            <span class="title">Mascotas</span>
          </a>
        </li>

        <li>
          <a href="historial.php">
            <span class="icon">
              <ion-icon name="pulse-outline"></ion-icon>
            </span>
            <span class="title">Historial medico</span>
          </a>
        </li>

        <li>
          <a href="vacunacion.php">
            <span class="icon">
              <ion-icon name="medkit-outline"></ion-icon>
            </span>
            <span class="title">Vacunaciones</span>
          </a>
        </li>

        <button id="logoutButton" class="button type1">Salir</button>
      </ul>
    </div>

    <!-- ========================= Main ==================== -->
    <div class="main">
      <div class="topbar">
        <div class="toggle">
          <ion-icon name="menu-outline"></ion-icon>
        </div>
      </div>

      <!-- ======================= Cards ================== -->
      <div class="cardBox2">
        <div class="card2">
          <h1>
            <div class="banner">
              <img
                src="./assets/imgs/perro.png"
                alt="Mr.Firulays"
                style="width: 14%; height: 14%" 
              />
              <span class="red">Mr</span>
              <span class="orange">.</span>
              <span class="blue">Firu</span>
              <span class="yellow">lays</span>
              <span class="green"></span>
              <span class="pink"></span>
            </div>
            <div class="banner2">
              <span class="green">Bienvenido</span>
              <span class="blue"></span> <span class="yellow"></span>
              <span class="green"></span>
            </div>
          </h1>
        </div>
      </div>

      <div class="cardBox">
        <?php
        // Incluir el archivo de conexión
        require 'conexion.php';

        // Consultar el número de clientes
        $sql_clientes = "SELECT COUNT(*) AS total_clientes FROM clientes";
        $result_clientes = $conn->query($sql_clientes);
        $total_clientes = $result_clientes->fetch_assoc()['total_clientes'];

        // Consultar el número de mascotas
        $sql_mascotas = "SELECT COUNT(*) AS total_mascotas FROM pacientes";
        $result_mascotas = $conn->query($sql_mascotas);
        $total_mascotas = $result_mascotas->fetch_assoc()['total_mascotas'];

        $sql_vacunas = "SELECT COUNT(*) AS total_vacunas FROM calendario_vacunacion";
        $result_vacunas = $conn->query($sql_vacunas);
        $total_vacunas = $result_vacunas->fetch_assoc()['total_vacunas'];

        // Cerrar conexión
        $conn->close();
        ?>

        <div class="card">
          <div>
            <div class="numbers"><?php echo $total_clientes; ?></div>
            <div class="cardName">Clientes</div>
          </div>

          <div class="iconBx">
            <ion-icon name="people-outline"></ion-icon>
          </div>
        </div>

        <div class="card">
          <div>
            <div class="numbers"><?php echo $total_mascotas; ?></div>
            <div class="cardName">Mascotas</div>
          </div>
          

          <div class="iconBx">
            <ion-icon name="paw-outline"></ion-icon>
          </div>
        </div>

        <div class="card">
          <div>
            <div class="numbers"><?php echo $total_vacunas; ?></div>
            <div class="cardName">Vacunas Aplicadas</div>
          </div>

          <div class="iconBx">
            <ion-icon name="medkit-outline"></ion-icon>
          </div>
        </div>


        </div>
      </div>
    </div>
  </div>

  <!-- =========== Scripts =========  -->
  <script src="assets/js/main.js"></script>

  <!-- ====== ionicons ======= -->
  <script
    type="module"
    src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"
  ></script>
  <script
    nomodule
    src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"
  ></script>

  <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if (isset($_GET['error']) && $_GET['error'] == 'true') { ?>
                Swal.fire({
                    icon: 'error',
                    title: 'Error de Autenticación',
                    text: 'Usuario o contraseña incorrectos.',
                    confirmButtonText: 'Aceptar'
                });
            <?php } elseif (isset($_GET['success']) && $_GET['success'] == 'true') { ?>
                Swal.fire({
                    icon: 'success',
                    title: 'Bienvenido',
                    text: 'Inicio de sesión exitoso.',
                    confirmButtonText: 'Aceptar'
                });
            <?php } ?>
        });
    </script>
  <!-- Script para el botón de salir -->
  <script>
    document.getElementById('logoutButton').addEventListener('click', function() {
      Swal.fire({
        title: '¿Estás seguro?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, salir',
        cancelButtonText: 'Cancelar'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.href = './index.php';
        }
      });
    });
  </script>
</body>
</html>
