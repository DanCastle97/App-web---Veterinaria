<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION["usuario"])) {
    // Redirige al usuario a la página de inicio de sesión si no está autenticado
    header("Location: index.php");
    exit();
}

// El resto del contenido de la página inicio.php
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Veterinaria</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
  </head>
  <style>
    /* Estilo para el modal */
.modal {
  display: none; /* Oculta el modal por defecto */
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.4); /* Fondo oscuro con opacidad */
}

.modal-content {
  background-color: #fefefe;
  margin: 1% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
  max-width: 600px; /* Limita el ancho máximo */
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Sombra alrededor del modal */
  border-radius: 10px; /* Bordes redondeados */
}

/* Estilo para el botón de cerrar */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

/* Estilo para el formulario dentro del modal */
form {
  margin-top: 20px;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 5px;
}

input[type="text"],
input[type="date"],
select {
  width: 100%;
  padding: 8px;
  margin: 5px 0;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 4px;
}


button[type="submit"] {
  background-color: #362baf;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  display: block;
  margin: 20px auto; /* Centra el botón */
}

button[type="submit"]:hover {
  background-color: #2a2182; /* Cambio de color al pasar el mouse */
}

</style>


  <body>
    <?php
        // Incluir el archivo de conexión
        require 'conexion.php';

        // Consultar el número de vacunas
        $sql_vacunas = "SELECT COUNT(*) AS total_vacunas FROM calendario_vacunacion";
        $result_vacunas = $conn->query($sql_vacunas);
        $total_vacunas = $result_vacunas->fetch_assoc()['total_vacunas'];

        // Consultar el número de mascotas
        $sql_mascotas = "SELECT COUNT(*) AS total_mascotas FROM pacientes";
        $result_mascotas = $conn->query($sql_mascotas);
        $total_mascotas = $result_mascotas->fetch_assoc()['total_mascotas'];

        // Cerrar conexión
        $conn->close();
    ?>
    <!-- =============== Navigation ================ -->
    <div class="container">
      <div class="navigation">
        <ul>
          <li>
            <a href="#">
              <span class="icon">
                <img
                  src="./assets/imgs/perro.png"
                  alt="Mr.Firulays"
                  style="width: 60px; height: 60px; padding-top: 6px"
                />
              </span>
              <span class="title"><span class="red">Mr</span>
              <span class="orange">.</span>
              <span class="blue">Firu</span>
              <span class="yellow">lays</span>
              <span class="green"></span>
              <span class="pink"></span></span>
            </a>
          </li>

          <li>
            <a href="./inicio.php">
              <span class="icon">
                <ion-icon name="home-outline"></ion-icon>
              </span>
              <span class="title">Inicio</span>
            </a>
          </li>

          <li>
            <a href="./clientes.php">
              <span class="icon">
                <ion-icon name="people-outline"></ion-icon>
              </span>
              <span class="title">Clientes</span>
            </a>
          </li>

          <li>
            <a href="./mascotas.php">
              <span class="icon">
                <ion-icon name="paw-outline"></ion-icon>
              </span>
              <span class="title">Mascotas</span>
            </a>
          </li>

          <li>
            <a href="./historial.php">
              <span class="icon">
                <ion-icon name="pulse-outline"></ion-icon>
              </span>
              <span class="title">Historial medico</span>
            </a>
          </li>

          <li>
            <a href="./vacunacion.php">
              <span class="icon">
                <ion-icon name="medkit-outline"></ion-icon>
              </span>
              <span class="title">Vacunaciones</span>
            </a>
          </li>

          <button class="button type1" id="salir">
          </button>
        </ul>
      </div>

      <!-- ========================= Main ==================== -->
      <div class="main">
        <div class="topbar">
          <div class="toggle">
            <ion-icon name="menu-outline"></ion-icon>
          </div>
        </div>

        <!-- ======================= Cards ================== -->
        <div class="cardBox">
          <div class="card">
            <div>
              <div class="numbers"><?php echo $total_vacunas; ?></div>
              <div class="cardName">Total vacunados</div>
            </div>

            <div class="iconBx">
              <ion-icon name="people-outline"></ion-icon>
            </div>
          </div>
        </div>

        <!-- ================ Order Details List ================= -->
        <div class="details">
          <div class="recentOrders">
            <div class="cardHeader">
              <h2>Lista de vacunas</h2>
              <a href="#" class="btn" id="addvacunaBtn">Añadir vacunacion</a>
            </div>
            <div class="cardHeader">
              <input
                type="text"
                id="searchInput"
                onkeyup="searchTable()"
                placeholder="Buscar paciente..."
                style="
                  padding: 8px;
                  margin-left: 20px;
                  border-radius: 4px;
                  border: 1px solid #ccc;
                "
              />
            </div>
            <div class="table-container">
            <table id="vacunacionTable">
              <thead>
                <tr>
                  <td>Vacuna</td>
                  <td>Paciente</td>
                  <td>Especie</td>
                  <td>Fecha de aplicacion</td>
                  <td>Enfermedad</td>
                </tr>
              </thead>

              <tbody>
                <?php
                // Conectar a la base de datos
                require 'conexion.php';
                
                // Ejecutar la consulta SQL
                $sql = "
                SELECT
                    cv.vacuna,
                    p.alias AS paciente,
                    p.especie,
                    cv.fecha_vacunacion AS fecha_aplicacion,
                    h.enfermedad
                FROM
                    calendario_vacunacion cv
                JOIN
                    pacientes p ON cv.id_paciente = p.id_paciente
                LEFT JOIN
                    historial h ON p.id_paciente = h.id_paciente
                ORDER BY
                    cv.fecha_vacunacion DESC;
                ";

                $result = mysqli_query($conn, $sql);

                // Mostrar los resultados
                while ($row = mysqli_fetch_assoc($result)) {
                  echo "<tr>";
                  echo "<td>" . htmlspecialchars($row['vacuna']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['paciente']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['especie']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['fecha_aplicacion']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['enfermedad']) . "</td>";
                  echo "</tr>";
                }

                // Cerrar la conexión
                mysqli_close($conn);
                ?>
                </div>
              </tbody>
            </table>

          </div>
        </div>
      </div>
    </div>

<!-- Modal -->
<div id="addVacunacionModal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2>Añadir Vacunación</h2>
    <form id="addVacunacionForm" action="guardar_vacunacion.php" method="post">
      <label for="id_paciente">Paciente:</label>
      <select id="id_paciente" name="id_paciente" required>
        <option value="">Selecciona un paciente</option>
        <!-- Opciones de pacientes se llenarán aquí -->
      </select><br>

      <label for="especie">Especie:</label>
      <input type="text" id="especie" name="especie" required><br>

      <label for="fecha_vacunacion">Fecha de Aplicación:</label>
      <input type="date" id="fecha_vacunacion" name="fecha_vacunacion" required><br>

      <label for="enfermedad_vacuna">Enfermedad:</label>
      <input type="text" id="enfermedad_vacuna" name="enfermedad_vacuna"><br>

      <label for="vacuna">Vacuna:</label>
      <input type="text" id="vacuna" name="vacuna" required><br>

      <button type="submit">Guardar</button>
    </form>
  </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', () => {
    loadPatientAliases();
});

function loadPatientAliases() {
    fetch('get_patients.php')
        .then(response => response.json())
        .then(data => {
            const select = document.getElementById('id_paciente');
            data.forEach(patient => {
                const option = document.createElement('option');
                option.value = patient.id_paciente;
                option.textContent = patient.alias;
                select.appendChild(option);
            });
        })
        .catch(error => console.error('Error al cargar pacientes:', error));
}
</script>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("#addVacunacionForm");

    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevenir el envío inmediato del formulario

        Swal.fire({
            title: '¿Estás seguro?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, guardar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                const formData = new FormData(form);
                fetch('guardar_vacunacion.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire({
                            title: 'Guardado exitosamente',
                            text: data.message, // Solo el mensaje de éxito
                            icon: 'success',
                            showConfirmButton: true
                        }).then(() => {
                            form.reset();
                            document.getElementById('addVacunacionModal').style.display = 'none';
                        });
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: data.message,
                            icon: 'error',
                            showConfirmButton: true
                        });
                    }
                })
                .catch(error => {
                    Swal.fire({
                        title: 'Error',
                        text: 'Hubo un problema al guardar la información.',
                        icon: 'error',
                        showConfirmButton: true
                    });
                    console.error('Error:', error);
                });
            }
        });
    });
});
</script>



<!-- Incluye SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  // Obtener el modal
  var modal = document.getElementById("addVacunacionModal");

  // Obtener el botón que abre el modal
  var btn = document.getElementById("addvacunaBtn");

  // Obtener el <span> que cierra el modal
  var span = document.getElementsByClassName("close")[0];

  // Cuando el usuario hace clic en el botón, abre el modal
  btn.onclick = function(event) {
    event.preventDefault(); // Prevenir el comportamiento por defecto del enlace
    modal.style.display = "block";
  }

  // Cuando el usuario hace clic en <span> (x), cierra el modal
  span.onclick = function() {
    modal.style.display = "none";
  }

  // Confirmar al guardar
  document.getElementById("addVacunacionForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevenir el envío por defecto del formulario

    Swal.fire({
      title: '¿Estás seguro?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí, guardar',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        // Enviar el formulario si el usuario confirma
        this.submit();
      }
    });
  });
</script>


    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script
      type="module"
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"
    ></script>
    <script
      nomodule
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"
    ></script>
    <script>
      // SweetAlert2 para el botón "Salir"
      document.getElementById("salir").addEventListener("click", function(event) {
        event.preventDefault(); // Prevenir el comportamiento por defecto

        Swal.fire({
          title: '¿Estás seguro?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Sí, salir',
          cancelButtonText: 'Cancelar'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = './index.php'; // Cambia la URL si es necesario
          }
        });
      });

      // Función para buscar en la tabla de vacunas
      
    </script>
    <script>
        function searchTable() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("searchInput");
            filter = input.value.toLowerCase();
            table = document.querySelector("table tbody");
            tr = table.getElementsByTagName("tr");

            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toLowerCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
  </body>
</html>
