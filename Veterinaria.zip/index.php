<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Mr. Firu Lays</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.css"
    />
    <link rel="stylesheet" href="./style.css" />
  </head>
  <body>
    <!-- partial:index.partial.html -->
    <div id="login-page">
      <div class="login">  
    <h2 class="login-title2">
    <img
                  src="./assets/imgs/veterinario.png"
                  alt="Mr.Firulays"
                  style="width: 40%; height: 30%"
                />
        </h2>
        <form action="login.php" method="post">
            <h1 class="animate__animated animate__backInLeft"></h1>
            <p class="blanco">Usuario <input type="text" placeholder="ingrese su nombre" name="usuario" required></p>
            <p class="blanco">Contraseña <input type="password" placeholder="ingrese su contraseña" name="password" required></p>
            <input class="btn btn-success" type="submit" value="Ingresar" >
        </form>
    <p class="textInf">Envia tu usuario y contraseña, para obtener acceso</p>
    <a>gerardo.escobar91@unach.mx</a>
    
</form>


      </div>
      <div class="background">
        <div class="cardBox2">
          <div class="card2">
            <h1>
              <div class="banner">
                <img
                  src="./assets/imgs/perro.png"
                  alt="Mr.Firulays"
                  style="width: 14%; height: 14%"
                />
                <span class="red">Mr</span>
                <span class="orange">.</span>
                <span class="blue">Firu</span>
                <span class="yellow">lays</span>
                <span class="green"></span>
                <span class="pink"></span>
              </div>
              <div class="banner2">
                <span class="green">Bienvenido</span>
                <span class="blue"></span> <span class="yellow"></span>
                <span class="green"></span>
              </div>
            </h1>
          </div>
        </div>
      </div>
    </div>
    <!-- partial -->
  </body>
   <!-- Script para mostrar alertas SweetAlert2 -->
   <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if (isset($_GET['error']) && $_GET['error'] == 'true') { ?>
                Swal.fire({
                    icon: 'error',
                    title: 'Error de Autenticación',
                    text: 'Usuario o contraseña incorrectos.',
                    confirmButtonText: 'Aceptar'
                });
            <?php } elseif (isset($_GET['success']) && $_GET['success'] == 'true') { ?>
                Swal.fire({
                    icon: 'success',
                    title: 'Bienvenido',
                    text: 'Inicio de sesión exitoso.',
                    confirmButtonText: 'Aceptar'
                });
            <?php } ?>
        });
    </script>
</html>


