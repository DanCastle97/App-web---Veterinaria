<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION["usuario"])) {
    // Redirige al usuario a la página de inicio de sesión si no está autenticado
    header("Location: index.php");
    exit();
}

// El resto del contenido de la página inicio.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Veterinaria</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
    <script>
        function searchTable() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("searchInput");
            filter = input.value.toLowerCase();
            table = document.querySelector("table tbody");
            tr = table.getElementsByTagName("tr");

            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[0];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toLowerCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</head>

<style>
 /* Estilo para el modal */
.modal {
  display: none; /* Oculta el modal por defecto */
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.4); /* Fondo oscuro con opacidad */
}

.modal-content {
  background-color: #fefefe;
  margin: 2% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
  max-width: 600px; /* Limita el ancho máximo */
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Sombra alrededor del modal */
  border-radius: 10px; /* Bordes redondeados */
}

/* Estilo para el botón de cerrar */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

/* Estilo para el formulario dentro del modal */
form {
  margin-top: 20px;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 5px;
}

input[type="text"],
input[type="date"],
select {
  width: 100%;
  padding: 8px;
  margin: 5px 0;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 4px;
}


button[type="submit"] {
  background-color: #362baf;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  display: block;
  margin: 20px auto; /* Centra el botón */
}

button[type="submit"]:hover {
  background-color: #2a2182; /* Cambio de color al pasar el mouse */
}


</style>

<body>
    <!-- =============== Navigation ================ -->
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon">
                            <img src="./assets/imgs/perro.png" alt="Mr.Firulays" style="width: 60px; height: 60px; padding-top: 6px" />
                        </span>
                        <span class="title"><span class="red">Mr</span>
              <span class="orange">.</span>
              <span class="blue">Firu</span>
              <span class="yellow">lays</span>
              <span class="green"></span>
              <span class="pink"></span></span>
                    </a>
                </li>
                <li>
                    <a href="./inicio.php">
                        <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="title">Inicio</span>
                    </a>
                </li>
                <li>
                    <a href="./clientes.php">
                        <span class="icon"><ion-icon name="people-outline"></ion-icon></span>
                        <span class="title">Clientes</span>
                    </a>
                </li>
                <li>
                    <a href="./mascotas.php">
                        <span class="icon"><ion-icon name="paw-outline"></ion-icon></span>
                        <span class="title">Mascotas</span>
                    </a>
                </li>
                <li>
                    <a href="./historial.php">
                        <span class="icon"><ion-icon name="pulse-outline"></ion-icon></span>
                        <span class="title">Historial medico</span>
                    </a>
                </li>
                <li>
                    <a href="./vacunacion.php">
                        <span class="icon"><ion-icon name="medkit-outline"></ion-icon></span>
                        <span class="title">Vacunaciones</span>
                    </a>
                </li>
                <button class="button type1" id="salir">Salir</button>
            </ul>
        </div>
        <!-- ========================= Main ==================== -->
        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
            </div>

            <!-- ================ Order Details List ================= -->
            <div class="details">
                <div class="recentOrders">
                    <div class="cardHeader">
                        <h2>Historial medico</h2>
                        <a href="#" class="btn" id="addhistorialBtn">Añadir Historial</a>
                    </div>
<!-- ======================= Cards ================== -->

                
                    <div class="cardHeaders">
                        
                        <form action="historial.php" method="get">
                        <input
                type="text"
                id="searchInput"
                onkeyup="searchTable()"
                placeholder="Buscar Paciente..."
                style="
                  padding: 8px;
                  margin-left: 0px;
                  border-radius: 4px;
                  border: 1px solid #ccc;
                "
              />
                        </form>
                    </div>
                
                    <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <td>Paciente</td>
                                <td>Fecha</td>
                                <td>Enfermedad</td>
                                <td>Síntomas</td>
                                <td>Tratamiento</td>
                                <td>Próxima Visita</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Incluir archivo de conexión
                            include 'conexion.php';

                            // Obtener el alias de búsqueda, si se ha enviado
                            $alias = isset($_GET['search']) ? $_GET['search'] : '';

                            // Consulta SQL para obtener datos del historial
                            $sql = "SELECT h.id_clave, p.alias AS paciente, h.fecha_enf AS fecha, h.enfermedad, h.sintomas, h.tratamiento, h.proxima_visita
                                    FROM historial h
                                    JOIN pacientes p ON h.id_paciente = p.id_paciente
                                    WHERE p.alias LIKE ?";
                            $stmt = $conn->prepare($sql);
                            $searchParam = '%' . $alias . '%';
                            $stmt->bind_param('s', $searchParam);
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                // Mostrar datos de cada fila
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                            <td>" . htmlspecialchars($row["paciente"]) . "</td>
                                            <td>" . htmlspecialchars($row["fecha"]) . "</td>
                                            <td>" . htmlspecialchars($row["enfermedad"]) . "</td>
                                            <td>" . htmlspecialchars($row["sintomas"]) . "</td>
                                            <td>" . htmlspecialchars($row["tratamiento"]) . "</td>
                                            <td>" . htmlspecialchars($row["proxima_visita"]) . "</td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='6'>No hay registros</td></tr>";
                            }

                            $stmt->close();
                            $conn->close();
                            ?>
                            </div>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Modal para Añadir/Edit Historial -->
<!-- Modal HTML -->
<div id="addHistorialModal" class="modal">
  <div class="modal-content">
    <span class="close" id="closeHistorialModal">&times;</span>
    <h2>Historial Médico</h2>
    <form id="addHistorialForm" action="guardar_historial.php" method="post">
      <input type="hidden" id="id_clave" name="id_clave" /> <!-- Campo oculto para el ID -->

      <label for="id_paciente">Paciente:</label>
      <select id="id_paciente" name="id_paciente" required>
        <option value="">Selecciona un paciente</option>
      </select><br>

      <label for="fecha_enf">Fecha:</label>
      <input type="date" id="fecha_enf" name="fecha_enf" required><br>

      <label for="enfermedad">Enfermedad:</label>
      <input type="text" id="enfermedad" name="enfermedad" required><br>

      <label for="sintomas">Síntomas:</label>
      <input type="text" id="sintomas" name="sintomas" required><br>

      <label for="tratamiento">Tratamiento:</label>
      <input type="text" id="tratamiento" name="tratamiento" required><br>

      <label for="proxima_visita">Próxima Visita:</label>
      <input type="date" id="proxima_visita" name="proxima_visita"><br>

      <button type="submit">Guardar</button>
    </form>
  </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    var modal = document.getElementById("addHistorialModal");
    var openBtn = document.getElementById("addhistorialBtn");
    var closeBtn = document.getElementById("closeHistorialModal");
    var form = document.getElementById("addHistorialForm");

    // Abre el modal
    openBtn.onclick = function() {
        modal.style.display = "block";
    };

    // Cierra el modal
    closeBtn.onclick = function() {
        modal.style.display = "none";
    };



    // Manejador de envío del formulario
    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Evita que el formulario se envíe de forma tradicional

        const formData = new FormData(form);

        fetch('guardar_historial.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            console.log('Response data:', data); // Para depuración
            if (data.status === 'success') {
                alert('Guardado exitosamente');
                modal.style.display = "none"; // Cierra el modal
                form.reset(); // Limpia el formulario
                // location.reload(); // Opcional: Recarga la página para actualizar la lista
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Hubo un problema con la solicitud.');
        });
    });
});


</script>




<script>
document.addEventListener('DOMContentLoaded', () => {
    loadPatientAliases();
});

function loadPatientAliases() {
    fetch('get_patients.php')
        .then(response => response.json())
        .then(data => {
            const select = document.getElementById('id_paciente');
            data.forEach(patient => {
                const option = document.createElement('option');
                option.value = patient.id_paciente;
                option.textContent = patient.alias;
                select.appendChild(option);
            });
        })
        .catch(error => console.error('Error al cargar pacientes:', error));
}
</script>
</div>
</div>

    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script
      type="module"
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"
    ></script>
    <script
      nomodule
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"
    ></script>
    <script>
      // SweetAlert2 para el botón "Salir"
      document.getElementById("salir").addEventListener("click", function(event) {
        event.preventDefault(); // Prevenir el comportamiento por defecto

        Swal.fire({
          title: '¿Estás seguro?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Sí, salir',
          cancelButtonText: 'Cancelar'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = './index.php'; // Cambia la URL si es necesario
          }
        });
      });
    </script>
</body>
</html>
