<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION["usuario"])) {
    // Redirige al usuario a la página de inicio de sesión si no está autenticado
    header("Location: index.php");
    exit();
}

// El resto del contenido de la página inicio.php
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Veterinaria</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <style>
      /* Estilo para el modal */
  /* Estilo para el modal */
  .modal {
  display: none; /* Oculta el modal por defecto */
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.4); /* Fondo oscuro con opacidad */
}

.modal-content {
  background-color: #fefefe;
  margin: 2% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
  max-width: 800px; /* Limita el ancho máximo */
  max-height: 720px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Sombra alrededor del modal */
  border-radius: 10px; /* Bordes redondeados */
}

/* Estilo para el botón de cerrar */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

/* Estilo para la tabla dentro del modal */
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}

td {
  padding: 10px;
  vertical-align: middle;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 5px;
}

input[type="text"] {
  width: 100%;
  padding: 8px;
  margin: 5px 0;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button[type="submit"] {
  background-color: #362baf;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  display: block;
  margin: 20px auto; /* Centra el botón */
}

button[type="submit"]:hover {
  background-color: #2a2182; /* Cambio de color al pasar el mouse */
}

/* El botón de cerrar (x) */
.modal-close {
  color: #007bff; /* Azul brillante para el botón de cerrar */
  float: right;
  font-size: 28px;
  font-weight: bold;
  cursor: pointer;
}

.modal-close:hover,
.modal-close:focus {
  color: #0056b3; /* Azul más oscuro al pasar el cursor */
  text-decoration: none;
}

/* Modal de Edición */
/* Estilo general para el modal */
.modal-edit {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.4);
      }

      /* Contenido del Modal de Edición */
      .modal-edit-content {
        background-color: #fefefe;
        margin: 1% auto;
        padding: 15px;
        border: 1px solid #888;
        width: 90%;
        max-width: 600px; /* Ancho máximo reducido */
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      }

      /* Botón de cerrar (x) */
      .close-edit {
        color: #007bff;
        float: right;
        font-size: 24px; /* Tamaño reducido */
        font-weight: bold;
        cursor: pointer;
      }

      .close-edit:hover,
      .close-edit:focus {
        color: #0056b3;
        text-decoration: none;
      }

      /* Botones dentro del modal */
      .modal-edit button {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 8px 16px; /* Padding reducido */
        font-size: 14px; /* Tamaño de fuente reducido */
        margin: 10px 0;
        cursor: pointer;
        border-radius: 4px;
        width: 100%; /* Botones de ancho completo */
      }

      .modal-edit button:hover {
        background-color: #0056b3;
      }

      /* Campos de entrada */
      .modal-edit input[type="text"] {
        width: calc(100% - 20px);
        padding: 8px; /* Padding reducido */
        margin: 6px 0;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px; /* Tamaño de fuente reducido */
      }

      .modal-edit input[type="text"]:focus {
        border-color: #007bff;
        outline: none;
      }

      /* Labels de los campos */
      .modal-edit label {
        font-size: 14px; /* Tamaño de fuente reducido */
        font-weight: bold;
        margin-bottom: 4px;
        display: block;
      }
      .edit-btn {
    background-color: #2a2185; /* Color de fondo */
    color: #ffffff; /* Color del texto */
    border: none; /* Sin bordes */
    padding: 10px 20px; /* Espaciado interno */
    border-radius: 12px; /* Esquinas redondeadas */
    cursor: pointer; /* Cambia el cursor al pasar por encima */
    font-size: 14px; /* Tamaño del texto */
    transition: background-color 0.3s ease; /* Transición suave del color de fondo */
}

.delete-btn {
    background-color: #cd0000; /* Color de fondo */
    color: #ffffff; /* Color del texto */
    border: none; /* Sin bordes */
    padding: 10px 15px; /* Espaciado interno */
    border-radius: 12px; /* Esquinas redondeadas */
    cursor: pointer; /* Cambia el cursor al pasar por encima */
    font-size: 14px; /* Tamaño del texto */
    transition: background-color 0.3s ease; /* Transición suave del color de fondo */
}


.editar-btn:hover {
    background-color: #1e1864; /* Color de fondo al pasar el mouse */
}
    </style>
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
  </head>

  <body>
    <?php
      // Incluir el archivo de conexión
      require 'conexion.php';

      // Consultar el número de clientes
      $sql_clientes = "SELECT COUNT(*) AS total_clientes FROM clientes";
      $result_clientes = $conn->query($sql_clientes);
      $total_clientes = $result_clientes->fetch_assoc()['total_clientes'];

      // Consultar el número de mascotas
      $sql_mascotas = "SELECT COUNT(*) AS total_mascotas FROM pacientes";
      $result_mascotas = $conn->query($sql_mascotas);
      $total_mascotas = $result_mascotas->fetch_assoc()['total_mascotas'];

      // Cerrar conexión
      $conn->close();
    ?>
    <!-- =============== Navigation ================ -->
    <div class="container">
      <div class="navigation">
        <ul>
          <li>
            <a href="#">
              <span class="icon">
                <img
                  src="./assets/imgs/perro.png"
                  alt="Mr.Firulays"
                  style="width: 60px; height: 60px; padding-top: 6px"
                />
              </span>
               <span class="title"><span class="red">Mr</span>
              <span class="orange">.</span>
              <span class="blue">Firu</span>
              <span class="yellow">lays</span>
              <span class="green"></span>
              <span class="pink"></span></span>
            </a>
          </li>

          <li>
            <a href="./inicio.php">
              <span class="icon">
                <ion-icon name="home-outline"></ion-icon>
              </span>
              <span class="title">Inicio</span>
            </a>
          </li>

          <li>
            <a href="./clientes.php">
              <span class="icon">
                <ion-icon name="people-outline"></ion-icon>
              </span>
              <span class="title">Clientes</span>
            </a>
          </li>

          <li>
            <a href="./mascotas.php">
              <span class="icon">
                <ion-icon name="paw-outline"></ion-icon>
              </span>
              <span class="title">Mascotas</span>
            </a>
          </li>

          <li>
            <a href="./historial.php">
              <span class="icon">
                <ion-icon name="pulse-outline"></ion-icon>
              </span>
              <span class="title">Historial medico</span>
            </a>
          </li>

          <li>
            <a href="./vacunacion.php">
              <span class="icon">
                <ion-icon name="medkit-outline"></ion-icon>
              </span>
              <span class="title">Vacunaciones</span>
            </a>
          </li>

          <button class="button type1" id="salir">Salir</button>
        </ul>
      </div>
      <div class="main">
        <div class="topbar">
          <div class="toggle">
            <ion-icon name="menu-outline"></ion-icon>
          </div>
        </div>

        <!-- ======================= Cards ================== -->
        <div class="cardBox">
          <div class="card">
            <div>
              <div class="numbers"><?php echo $total_clientes; ?></div>
              <div class="cardName">Clientes</div>
            </div>

            <div class="iconBx">
              <ion-icon name="people-outline"></ion-icon>
            </div>
          </div>
        </div>

        <div class="details">
          <div class="recentOrders">
            <div class="cardHeader">
              <h2>Lista de clientes</h2>
              <a href="#" class="btn" id="addClientBtn">Añadir clientes</a>
            </div>
            <div class="cardHeader">
              <input
                type="text"
                id="searchInput"
                onkeyup="searchTable()"
                placeholder="Buscar Cliente..."
                style="
                  padding: 8px;
                  margin-left: 20px;
                  border-radius: 4px;
                  border: 1px solid #ccc;
                "
              />
            </div>
            <div class="table-container">
            <table id="dataTable">
            
              <thead>
                <tr>
                  <td>Nombre</td>
                  <td>Apellidos</td>
                  <td>Dirección</td>
                  <td>Teléfono</td>
                  <td>RFC</td>
                  <td>C.P.</td>
                  <td>Num. cuenta</td>
                  <td>Num. Mascotas</td>
                  <td>Contacto extra</td>
                </tr>
              </thead>
              <tbody>
           
<?php
// Incluir el archivo de conexión
require 'conexion.php';

// Consultar la tabla de clientes
$sql = "SELECT * FROM clientes";
$result = $conn->query($sql);

// Mostrar los datos en la tabla
while ($row = $result->fetch_assoc()) {
  // Obtener los últimos 4 dígitos del número de cuenta
  $numCuentaUltimos4 = substr($row['num_cuenta'], -4);

  echo "<tr>
          <td>{$row['nombre']}</td>
          <td>{$row['apellidos']}</td>
          <td>{$row['direccion']}</td>
          <td>{$row['telefono']}</td>
          <td>{$row['RFC']}</td>
          <td>{$row['codigo_postal']}</td>
          <td>{$numCuentaUltimos4}</td>
          <td>{$row['mascotas']}</td>
          <td>{$row['contactos_extra']}</td>
          <td>  <button class='delete-btn' data-id_cliente='{$row['id_cliente']}'>Eliminar</button> </td>
  <td>
      <button class='edit-btn' data-id_cliente='{$row['id_cliente']}' data-nombre='{$row['nombre']}' data-apellidos='{$row['apellidos']}' data-direccion='{$row['direccion']}' data-num_cuenta='{$row['num_cuenta']}' data-telefono='{$row['telefono']}' data-contactos_extra='{$row['contactos_extra']}' data-correo='{$row['correo']}' data-codigo_postal='{$row['codigo_postal']}' data-RFC='{$row['RFC']}' data-mascotas='{$row['mascotas']}'>Editar</button>
  </td>  
        </tr>";
}

// Cerrar la conexión
$conn->close();
?>


</div>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal para editar cliente -->
<div id="editModal" class="modal-edit">
    <div class="modal-edit-content">
        <span class="close-edit">&times;</span>
        <h2>Editar Cliente</h2>
        <form id="editForm">
            <input type="hidden" id="editIdCliente" name="id_cliente" />

            <label for="editNombre">Nombre:</label>
            <input type="text" id="editNombre" name="nombre" required />

            <label for="editApellidos">Apellidos:</label>
            <input type="text" id="editApellidos" name="apellidos" required />

            <label for="editDireccion">Dirección:</label>
            <input type="text" id="editDireccion" name="direccion" required />

            <label for="editNumCuenta">Número de Cuenta:</label>
            <input type="text" id="editNumCuenta" name="num_cuenta" required />

            <label for="editTelefono">Teléfono:</label>
            <input type="text" id="editTelefono" name="telefono" required />

            <label for="editContactosExtra">Contactos Extra:</label>
            <input type="text" id="editContactosExtra" name="contactos_extra" />

            <label for="editCorreo">Correo:</label>
            <input type="text" id="editCorreo" name="correo" />

            <label for="editCodigoPostal">Código Postal:</label>
            <input type="text" id="editCodigoPostal" name="codigo_postal" />

            <label for="editRFC">RFC:</label>
            <input type="text" id="editRFC" name="RFC" />

            <label for="editMascotas">Mascotas:</label>
            <input type="text" id="editMascotas" name="mascotas" />

            <button type="submit">Guardar Cambios</button>
        </form>
    </div>
</div>


    </div>
</div>

<script>
    // Función para mostrar el modal y llenar los campos con datos del cliente
    document.querySelectorAll('.edit-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const id_cliente = e.target.getAttribute('data-id_cliente');
            const apellidos = e.target.getAttribute('data-apellidos');
            const nombre = e.target.getAttribute('data-nombre');
            const direccion = e.target.getAttribute('data-direccion');
            const numCuenta = e.target.getAttribute('data-num_cuenta');
            const telefono = e.target.getAttribute('data-telefono');
            const contactosExtra = e.target.getAttribute('data-contactos_extra');
            const correo = e.target.getAttribute('data-correo');
            const codigoPostal = e.target.getAttribute('data-codigo_postal');
            const rfc = e.target.getAttribute('data-rfc');
            const mascotas = e.target.getAttribute('data-mascotas');

            // Llenar los campos del formulario con los datos del cliente
            document.getElementById('editIdCliente').value = id_cliente; // No editable
            document.getElementById('editApellidos').value = apellidos;
            document.getElementById('editNombre').value = nombre;
            document.getElementById('editDireccion').value = direccion;
            document.getElementById('editNumCuenta').value = numCuenta;
            document.getElementById('editTelefono').value = telefono;
            document.getElementById('editContactosExtra').value = contactosExtra;
            document.getElementById('editCorreo').value = correo;
            document.getElementById('editCodigoPostal').value = codigoPostal;
            document.getElementById('editRFC').value = rfc;
            document.getElementById('editMascotas').value = mascotas;
            document.getElementById('editModal').style.display = 'block';
        });
    });

    document.getElementById("editForm").onsubmit = function(event) {
    event.preventDefault(); // Prevenir el envío por defecto del formulario

    var formData = new FormData(this);

    fetch('actualizar_cliente.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        console.log(result); // Verifica la respuesta en la consola

        if (result.includes('actualizado')) {
            Swal.fire({
                title: 'Éxito',
                text: 'El cliente ha sido actualizado correctamente.',
                icon: 'success',
                confirmButtonText: 'Aceptar'
            }).then(() => {
                // Redirigir a la página principal o recargar
                window.location.href = 'clientes.php'; // Cambia según tu necesidad
            });
        } else {
            Swal.fire({
                title: 'Error',
                text: result, // Mostrar el error detallado
                icon: 'error',
                confirmButtonText: 'Aceptar'
            });
        }
    })
    .catch(error => {
        Swal.fire({
            title: 'Error',
            text: 'Ocurrió un error en la solicitud. Inténtalo de nuevo más tarde.',
            icon: 'error',
            confirmButtonText: 'Aceptar'
        });
    });
}

// Función para cerrar el modal
document.querySelector('.close-edit').addEventListener('click', () => {
    document.getElementById('editModal').style.display = 'none';
});

// Cerrar el modal si el usuario hace clic fuera del contenido del modal
window.addEventListener('click', (event) => {
    if (event.target == document.getElementById('editModal')) {
        document.getElementById('editModal').style.display = 'none';
    }
});

document.querySelectorAll('.delete-btn').forEach(button => {
    button.addEventListener('click', (e) => {
        const id_cliente = e.target.getAttribute('data-id_cliente');

        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡No podrás revertir esto!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                // Realizar la solicitud de eliminación
                fetch('eliminar_cliente.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        'id_cliente': id_cliente
                    })
                })
                .then(response => response.text())
                .then(result => {
                    if (result.includes('eliminado')) {
                        Swal.fire({
                            title: 'Eliminado',
                            text: 'El cliente ha sido eliminado correctamente.',
                            icon: 'success',
                            confirmButtonText: 'Aceptar'
                        }).then(() => {
                            // Recargar la página o eliminar la fila de la tabla
                            location.reload(); // O usa una función para eliminar la fila
                        });
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: result,
                            icon: 'error',
                            confirmButtonText: 'Aceptar'
                        });
                    }
                })
                .catch(error => {
                    Swal.fire({
                        title: 'Error',
                        text: 'Ocurrió un error en la solicitud. Inténtalo de nuevo más tarde.',
                        icon: 'error',
                        confirmButtonText: 'Aceptar'
                    });
                });
            }
        });
    });
});
</script>

    <!-- =========== Modal para añadir nuevo cliente =========== -->
    <div id="clientModal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2>Nuevo Cliente</h2>
    <form action="guardar_cliente.php" method="post">
      <table>
        <tbody>
          <!-- Primera fila: Nombre -->
          <tr>
            <td colspan="4"><label for="nombre">Nombre:</label></td>
          </tr>
          <tr>
            <td colspan="4"><input type="text" id="nombre" name="nombre" required style="width: 100%;"></td>
          </tr>

          <!-- Segunda fila: Apellidos -->
          <tr>
            <td colspan="4"><label for="apellidos">Apellidos:</label></td>
          </tr>
          <tr>
            <td colspan="4"><input type="text" id="apellidos" name="apellidos" required style="width: 100%;"></td>
          </tr>

          <!-- Tercera fila: Dirección -->
          <tr>
            <td colspan="4"><label for="direccion">Dirección:</label></td>
          </tr>
          <tr>
            <td colspan="4"><input type="text" id="direccion" name="direccion" required style="width: 100%;"></td>
          </tr>

          <!-- Cuarta fila: Teléfono y Correo -->
          <tr>
            <td><label for="telefono">Teléfono:</label></td>
            <td><input type="text" id="telefono" name="telefono" required></td>
            <td><label for="correo">Correo:</label></td>
            <td><input type="text" id="correo" name="correo" required></td>
          </tr>

          <!-- Quinta fila: RFC -->
          <tr>
            <td><label for="RFC">RFC:</label></td>
            <td colspan="3"><input type="text" id="RFC" name="RFC" required style="width: 100%;"></td>
          </tr>

          <!-- Sexta fila: Código Postal y Número de Cuenta -->
          <tr>
            <td><label for="codigo_postal">Código Postal:</label></td>
            <td><input type="text" id="codigo_postal" name="codigo_postal" required></td>
            <td><label for="num_cuenta">Número de Cuenta:</label></td>
            <td><input type="text" id="num_cuenta" name="num_cuenta" required></td>
          </tr>

          <!-- Séptima fila: Contacto Extra y Mascota -->
          <tr>
            <td><label for="contactos_extra">Contacto Extra:</label></td>
            <td><input type="text" id="contactos_extra" name="contactos_extra"></td>
            <td><label for="mascotas">Num.Mascotas:</label></td>
            <td><input type="text" id="mascotas" name="mascotas"></td>
          </tr>

          <!-- Octava fila: Botón de Guardar -->
          <tr>
            <td colspan="4" style="text-align: center;">
              <button type="submit">Guardar</button>
            </td>
          </tr>
        </tbody>
      </table>
    </form>
  </div>
</div>


</div>


   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Mostrar mensaje de error si existe
    if (localStorage.getItem('error_message')) {
        Swal.fire({
            title: 'Error',
            text: localStorage.getItem('error_message'),
            icon: 'error',
            confirmButtonText: 'OK'
        });
        localStorage.removeItem('error_message'); // Limpiar el mensaje después de mostrarlo
    }

    // Mostrar mensaje de éxito si existe
    if (localStorage.getItem('success_message')) {
        Swal.fire({
            title: 'Guardado exitosamente',
            text: localStorage.getItem('success_message'),
            icon: 'success',
            confirmButtonText: 'OK'
        });
        localStorage.removeItem('success_message'); // Limpiar el mensaje después de mostrarlo
    }

    // Formulario y validación
    const form = document.querySelector("#clientModal form");
    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevenir el envío inmediato del formulario

        // Mostrar el SweetAlert para la confirmación
        Swal.fire({
            title: '¿Estás seguro?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, guardar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                // Enviar el formulario si se confirma
                form.submit();
            }
        });
    });
});
</script>
    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

    <script>
        function searchTable() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("searchInput");
            filter = input.value.toLowerCase();
            table = document.querySelector("table tbody");
            tr = table.getElementsByTagName("tr");

            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[0];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toLowerCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>

    <!-- JavaScript para manejar el modal -->
    <script>
      // Obtener el modal
      var modal = document.getElementById("clientModal");

      // Obtener el botón que abre el modal
      var btn = document.getElementById("addClientBtn");

      // Obtener el elemento <span> que cierra el modal
      var span = document.getElementsByClassName("close")[0];

      // Función para abrir el modal
      function openModal() {
        modal.style.display = "block";
      }

      // Cuando el usuario hace clic en el botón "Añadir clientes", abre el modal 
      btn.onclick = openModal;

      // Cuando el usuario hace clic en <span> (x), cierra el modal
      span.onclick = function() {
        modal.style.display = "none";
      }

 

      // SweetAlert para el botón salir
      document.getElementById("salir").addEventListener("click", function(event) {
        event.preventDefault(); // Prevenir el comportamiento por defecto

        Swal.fire({
          title: '¿Estás seguro?',
          text: '¿Quieres salir de la página?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Sí, salir',
          cancelButtonText: 'Cancelar'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = './index.php'; // Cambia la URL si es necesario
          }
        });
      });
    </script>
  </body>
</html>
