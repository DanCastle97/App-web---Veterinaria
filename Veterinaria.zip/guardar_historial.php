<?php
require 'conexion.php'; // Incluye el archivo de conexión

// Obtener los datos del formulario
$id_clave = $_POST['id_clave']; // ID del historial (para actualizar)
$id_paciente = $_POST['id_paciente'];
$fecha_enf = $_POST['fecha_enf'];
$enfermedad = $_POST['enfermedad'];
$sintomas = $_POST['sintomas'];
$tratamiento = $_POST['tratamiento'];
$proxima_visita = $_POST['proxima_visita'];

// Verificar si el ID del historial es vacío (nuevo registro) o no (actualización)
if (empty($id_clave)) {
    // Inserción de nuevo historial
    $sql = "INSERT INTO historial (id_paciente, fecha_enf, enfermedad, sintomas, tratamiento, proxima_visita) VALUES (?, ?, ?, ?, ?, ?)";
} else {
    // Actualización de historial existente
    $sql = "UPDATE historial SET id_paciente = ?, fecha_enf = ?, enfermedad = ?, sintomas = ?, tratamiento = ?, proxima_visita = ? WHERE id_clave = ?";
}

$stmt = $conn->prepare($sql);

if (!$stmt) {
    // Maneja el error de la preparación de la consulta
    echo json_encode(['status' => 'error', 'message' => 'Error en la preparación de la consulta.']);
    exit();
}

if (empty($id_clave)) {
    $stmt->bind_param("ssssss", $id_paciente, $fecha_enf, $enfermedad, $sintomas, $tratamiento, $proxima_visita);
} else {
    $stmt->bind_param("sssssss", $id_paciente, $fecha_enf, $enfermedad, $sintomas, $tratamiento, $proxima_visita, $id_clave);
}

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Guardado exitosamente.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error al guardar: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
