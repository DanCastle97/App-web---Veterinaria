<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Veterinaria</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
  </head>
  <style>
    /* Estilos para el modal */
    /* Estilo para el modal */
.modal {
  display: none; /* Oculta el modal por defecto */
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.4); /* Fondo oscuro con opacidad */
}

.modal-content {
  background-color: #fefefe;
  margin: 2% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
  max-width: 600px; /* Limita el ancho máximo */
  max-height: 750px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Sombra alrededor del modal */
  border-radius: 10px; /* Bordes redondeados */
}

/* Estilo para el botón de cerrar */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

/* Estilo para el formulario dentro del modal */
form {
  margin-top: 20px;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 5px;
}

input[type="text"],
input[type="date"],
input[type="number"],
select {
  width: 100%;
  padding: 8px;
  margin: 5px 0;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 4px;
}

input[type="file"] {
  margin: 5px 0;
}

button[type="submit"] {
  background-color: #362baf;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  display: block;
  margin: 20px auto; /* Centra el botón */
}

button[type="submit"]:hover {
  background-color: #2a2182; /* Cambio de color al pasar el mouse */
}

  </style>

<?php
      // Incluir el archivo de conexión
      require 'conexion.php';

      // Consultar el número de clientes
      $sql_clientes = "SELECT id_cliente, CONCAT(apellidos, ', ', nombre) AS nombre_completo FROM clientes";
      $result_clientes = $conn->query($sql_clientes);
      $clientes = $result_clientes->fetch_all(MYSQLI_ASSOC);

      // Consultar el número de mascotas
      $sql_mascotas = "SELECT COUNT(*) AS total_mascotas FROM pacientes";
      $result_mascotas = $conn->query($sql_mascotas);
      $total_mascotas = $result_mascotas->fetch_assoc()['total_mascotas'];

      // Verificar si se ha seleccionado una mascota para mostrar detalles
      $mascota_id = isset($_GET['id']) ? $_GET['id'] : '';
      if ($mascota_id) {
          // Consultar detalles de la mascota
          $sql_detalles = "SELECT p.alias, p.especie, p.raza, p.color_pelo, p.peso_actual, p.fecha_nacimiento, c.nombre AS dueño
                           FROM pacientes p
                           JOIN clientes c ON p.id_cliente = c.id_cliente
                           WHERE p.id_paciente = ?";
          $stmt = $conn->prepare($sql_detalles);
          $stmt->bind_param("s", $mascota_id);
          $stmt->execute();
          $result_detalles = $stmt->get_result();
          $mascota = $result_detalles->fetch_assoc();
      }

      // Cerrar conexión
      $conn->close();
    ?>

  <body>
    <?php
      // Incluir el archivo de conexión
      require 'conexion.php';

      // Consultar el número de clientes
      $sql_clientes = "SELECT COUNT(*) AS total_clientes FROM clientes";
      $result_clientes = $conn->query($sql_clientes);
      $total_clientes = $result_clientes->fetch_assoc()['total_clientes'];

      // Consultar el número de mascotas
      $sql_mascotas = "SELECT COUNT(*) AS total_mascotas FROM pacientes";
      $result_mascotas = $conn->query($sql_mascotas);
      $total_mascotas = $result_mascotas->fetch_assoc()['total_mascotas'];

      // Verificar si se ha seleccionado una mascota para mostrar detalles
      $mascota_id = isset($_GET['id']) ? $_GET['id'] : '';
      if ($mascota_id) {
          // Consultar detalles de la mascota
          $sql_detalles = "SELECT p.alias, p.especie, p.raza, p.color_pelo, p.peso_actual, p.fecha_nacimiento, c.nombre AS dueño
                           FROM pacientes p
                           JOIN clientes c ON p.id_cliente = c.id_cliente
                           WHERE p.id_paciente = ?";
          $stmt = $conn->prepare($sql_detalles);
          $stmt->bind_param("s", $mascota_id);
          $stmt->execute();
          $result_detalles = $stmt->get_result();
          $mascota = $result_detalles->fetch_assoc();
      }

      // Cerrar conexión
      $conn->close();
    ?>

    <!-- =============== Navigation ================ -->
    <div class="container">
      <div class="navigation">
        <ul>
          <li>
            <a href="#">
              <span class="icon">
                <img
                  src="./assets/imgs/perro.png"
                  alt="Mr.Firulays"
                  style="width: 60px; height: 60px; padding-top: 6px"
                />
              </span>
              <span class="title"><span class="red">Mr</span>
              <span class="orange">.</span>
              <span class="blue">Firu</span>
              <span class="yellow">lays</span>
              <span class="green"></span>
              <span class="pink"></span></span>
            </a>
          </li>

          <li>
            <a href="./inicio.php">
              <span class="icon">
                <ion-icon name="home-outline"></ion-icon>
              </span>
              <span class="title">Inicio</span>
            </a>
          </li>

          <li>
            <a href="./clientes.php">
              <span class="icon">
                <ion-icon name="people-outline"></ion-icon>
              </span>
              <span class="title">Clientes</span>
            </a>
          </li>

          <li>
            <a href="./mascotas.php">
              <span class="icon">
                <ion-icon name="paw-outline"></ion-icon>
              </span>
              <span class="title">Mascotas</span>
            </a>
          </li>

          <li>
            <a href="./historial.php">
              <span class="icon">
                <ion-icon name="pulse-outline"></ion-icon>
              </span>
              <span class="title">Historial medico</span>
            </a>
          </li>

          <li>
            <a href="./vacunacion.php">
              <span class="icon">
                <ion-icon name="medkit-outline"></ion-icon>
              </span>
              <span class="title">Vacunaciones</span>
            </a>
          </li>
          <button class="button type1" id="salir">Salir</button>
        </ul>
      </div>
      <div class="main">
        <div class="topbar">
          <div class="toggle">
            <ion-icon name="menu-outline"></ion-icon>
          </div>
        </div>

        <!-- ======================= Cards ================== -->
        <div class="cardBox">
          <div class="card">
            <div>
              <div class="numbers"><?php echo $total_mascotas; ?></div>
              <div class="cardName">Mascotas</div>
            </div>

            <div class="iconBx">
              <ion-icon name="paw-outline"></ion-icon>
            </div>
          </div>
        </div>

        <!-- ================ lista de mascotas ================= -->
        <div class="details">
          <div class="recentOrders">
            <div class="cardHeader">
              <h2>Lista de mascotas</h2>
              <button id="addMascotaBtn" class="btn btn-primary">Añadir Mascota</button>
            </div>
            <!-- Sección de Detalles de Mascota -->
            <div class="container1">
              <!-- Sección de Detalles de Mascota -->
             <div class="card3">
    <h5 class="card-title2">Mascota</h5>
    <div class="photo-container">
    </div>
    <ul class="list-unstyled">
    
    <?php
// Incluir el archivo de conexión
require 'conexion.php';

// Verificar si se ha recibido un ID de mascota
if (isset($_GET['id'])) {
    $id_paciente = intval($_GET['id']);
    
    // Consultar los detalles de la mascota
    $sql_detalle = "
    SELECT p.alias, p.especie, p.raza, p.color_pelo, p.peso_actual, p.fecha_nacimiento, 
    CONCAT(c.nombre, ' ', c.apellidos) AS dueño, p.foto 
    FROM pacientes p
    JOIN clientes c ON p.id_cliente = c.id_cliente
    WHERE p.id_paciente = ?";

    $stmt = $conn->prepare($sql_detalle);
    $stmt->bind_param("i", $id_paciente);
    $stmt->execute();
    $result_detalle = $stmt->get_result();
    
    // Si la mascota existe
    if ($result_detalle->num_rows > 0) {
        $mascota = $result_detalle->fetch_assoc();
    } else {
        echo "Mascota no encontrada.";
        exit;
    }
    
    // Cerrar la declaración
    $stmt->close();
    
    // Cerrar la conexión
    $conn->close();
}
?>

<!-- Sección para Mostrar Detalles de la Mascota -->
<div class="photo-container">
    <?php 
    if (isset($mascota['foto']) && !empty($mascota['foto'])) {
        echo '<img src="./imagen_mascotas/' . htmlspecialchars($mascota['foto']) . '" alt="Foto de ' . htmlspecialchars($mascota['alias']) . '" style="max-width: 200px; max-height: 200px;">';
    } else {
        echo 'No hay foto disponible';
    }
    ?>
</div>

<ul class="list-unstyled">
    <li><strong>Alias:</strong> <?php echo isset($mascota['alias']) ? htmlspecialchars($mascota['alias']) : ''; ?></li>
    <li><strong>Especie:</strong> <?php echo isset($mascota['especie']) ? htmlspecialchars($mascota['especie']) : ''; ?></li>
    <li><strong>Raza:</strong> <?php echo isset($mascota['raza']) ? htmlspecialchars($mascota['raza']) : ''; ?></li>
    <li><strong>Pelaje:</strong> <?php echo isset($mascota['color_pelo']) ? htmlspecialchars($mascota['color_pelo']) : ''; ?></li>
    <li><strong>Peso:</strong> <?php echo isset($mascota['peso_actual']) ? htmlspecialchars($mascota['peso_actual']) : ''; ?></li>
    <li><strong>Fecha de nacimiento:</strong> <?php echo isset($mascota['fecha_nacimiento']) ? htmlspecialchars($mascota['fecha_nacimiento']) : ''; ?></li>
    <li><strong>Dueño:</strong> <?php echo isset($mascota['dueño']) ? htmlspecialchars($mascota['dueño']) : ''; ?></li>
</ul>


</div>
<!-- Sección de Lista de Mascotas -->
              <div class="card3">
    <h5 class="card-title2">Lista de mascotas</h5>
    <input type="text" id="search" placeholder="Buscar mascota" onkeyup="filterTable()">
    <div class="table-container">
    <table class="table table-striped" id="mascotasTable">
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
    <?php
    // Incluir el archivo de conexión
    require 'conexion.php';

    // Consultar lista de mascotas
    $sql_mascotas = "SELECT id_paciente, alias FROM pacientes";
    $result_mascotas = $conn->query($sql_mascotas);

    while ($row = $result_mascotas->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['alias']) . "</td>";
        echo "<td>
                <a href='?id=" . $row['id_paciente'] . "' class='btn btn-primary'>Ver</a>
                <button data-id='" . $row['id_paciente'] . "' class='btn btn-danger btn-delete'>Eliminar</button>
              </td>";
        echo "</tr>";
    }
    
    // Cerrar conexión
    $conn->close();
    ?>
    </div>
</tbody>

    </table>     
</div>

              
            </div>
            
          </div>
          <div id="addMascotaModal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2>Añadir Mascota</h2>
    <form id="addMascotaForm" action="guardar_mascota.php" method="POST" enctype="multipart/form-data">
      <!-- Campo de selección de cliente -->
      <label for="cliente">Cliente:</label>
      <select id="cliente" name="id_cliente" required>
        <option value="">Selecciona un cliente</option>
        <?php foreach ($clientes as $cliente): ?>
          <option value="<?php echo htmlspecialchars($cliente['id_cliente']); ?>">
            <?php echo htmlspecialchars($cliente['nombre_completo']); ?>
          </option>
        <?php endforeach; ?>
      </select>

      <!-- Campos del formulario -->
      <label for="alias">Alias:</label>
      <input type="text" id="alias" name="alias" required>

      <label for="especie">Especie:</label>
      <input type="text" id="especie" name="especie" required>

      <label for="raza">Raza:</label>
      <input type="text" id="raza" name="raza" required>

      <label for="color_pelo">Color de Pelo:</label>
      <input type="text" id="color_pelo" name="color_pelo" required>

      <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
      <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>

      <label for="peso_medio">Peso Medio:</label>
      <input type="number" id="peso_medio" name="peso_medio" step="0.01" required>

      <label for="peso_actual">Peso Actual:</label>
      <input type="number" id="peso_actual" name="peso_actual" step="0.01" required>

      <label for="foto">Foto:</label>
      <input type="file" id="foto" name="foto" accept="image/*" required>

      <button type="submit" id="guardarMascotaBtn">Guardar</button>
    </form>
  </div>
</div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        // Manejar el clic en el botón de eliminar
        $(document).on('click', '.btn-delete', function() {
            var idPaciente = $(this).data('id');
            
            // Mostrar el SweetAlert2 para confirmar la eliminación
            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡No podrás revertir esta acción!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Si se confirma, realizar la solicitud AJAX para eliminar el registro
                    $.ajax({
                        url: 'delete_mascota.php',
                        type: 'POST',
                        data: { id: idPaciente },
                        success: function(response) {
                            // Mostrar mensaje de éxito y recargar la tabla
                            Swal.fire(
                                '¡Eliminado!',
                                'La mascota ha sido eliminada.',
                                'success'
                            ).then(() => {
                                location.reload(); // Recargar la página para actualizar la lista
                            });
                        },
                        error: function() {
                            Swal.fire(
                                'Error',
                                'Hubo un problema al eliminar la mascota.',
                                'error'
                            );
                        }
                    });
                }
            });
        });
    });
</script>

    <script>
function filterTable() {
    // Obtén el valor del campo de búsqueda
    var input = document.getElementById('search');
    var filter = input.value.toLowerCase();
    var table = document.getElementById('mascotasTable');
    var trs = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');

    // Itera a través de todas las filas de la tabla
    for (var i = 0; i < trs.length; i++) {
        var td = trs[i].getElementsByTagName('td')[0]; // Obtén la primera celda (Nombre)
        if (td) {
            var txtValue = td.textContent || td.innerText;
            if (txtValue.toLowerCase().indexOf(filter) > -1) {
                trs[i].style.display = "";
            } else {
                trs[i].style.display = "none";
            }
        }
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const urlParams = new URLSearchParams(window.location.search);
            const status = urlParams.get('status');
            const message = urlParams.get('message');

            if (status === 'error') {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: decodeURIComponent(message),
                    confirmButtonText: 'OK'
                });
            } else if (status === 'success') {
                Swal.fire({
                    icon: 'success',
                    title: 'Éxito',
                    text: 'La información ha sido guardada exitosamente.',
                    confirmButtonText: 'OK'
                });
            }
        });
    </script>
    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    
    <!-- JavaScript para manejar el modal y el botón "Salir" -->
    <script>
      // SweetAlert2 para el botón "Salir"
      document.getElementById("salir").addEventListener("click", function(event) {
        event.preventDefault(); // Prevenir el comportamiento por defecto

        Swal.fire({
          title: '¿Estás seguro?',
          text: '¿Quieres salir de la página?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Sí, salir',
          cancelButtonText: 'Cancelar'
        }).then((result) => {
          if (result.isConfirmed) {
            // Redirigir a la página de salida
            window.location.href = './index.php';
          }
        });
      });

      // Mostrar el modal para añadir una mascota
      document.getElementById('addMascotaBtn').addEventListener('click', function() {
        document.getElementById('addMascotaModal').style.display = 'block';
      });

      // Cerrar el modal cuando se haga clic en la "x"
      document.querySelector('.close').addEventListener('click', function() {
        document.getElementById('addMascotaModal').style.display = 'none';
      });



      // SweetAlert2 para el guardado de mascota
      document.getElementById('guardarMascotaBtn').addEventListener('click', function(event) {
        event.preventDefault(); // Prevenir el comportamiento por defecto

        Swal.fire({
          title: '¿Estás seguro?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Sí, guardar',
          cancelButtonText: 'Cancelar'
        }).then((result) => {
          if (result.isConfirmed) {
            document.getElementById('addMascotaForm').submit();
          }
        });
      });

    </script>

    <!-- Modal para añadir mascota -->
    
  </body>
</html>
