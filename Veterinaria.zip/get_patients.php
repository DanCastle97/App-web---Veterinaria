<?php
require 'conexion.php'; // Incluye el archivo de conexión

// Preparar y ejecutar la consulta SQL para obtener los alias de pacientes
$sql = "SELECT id_paciente, alias FROM pacientes";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

// Crear un array para almacenar los pacientes
$patients = [];
while ($row = $result->fetch_assoc()) {
    $patients[] = $row;
}

// Devolver los datos en formato JSON
header('Content-Type: application/json');
echo json_encode($patients);

$stmt->close();
$conn->close();
?>
