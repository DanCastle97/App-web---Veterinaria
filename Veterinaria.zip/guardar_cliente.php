<?php
// Incluir el archivo de conexión
require 'conexion.php';

// Obtener los datos del formulario
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$correo = $_POST['correo'];
$RFC = $_POST['RFC'];
$codigo_postal = $_POST['codigo_postal'];
$num_cuenta = $_POST['num_cuenta'];
$contactos_extra = $_POST['contactos_extra'];
$mascotas = $_POST['mascotas'];

// Verificar si el RFC, correo, num_cuenta, telefono o contactos_extra ya existen en la base de datos
$sql_check = "SELECT id_cliente FROM clientes WHERE RFC = '$RFC' OR correo = '$correo' OR num_cuenta = '$num_cuenta' OR telefono = '$telefono' OR contactos_extra = '$contactos_extra'";
$result_check = $conn->query($sql_check);

if ($result_check->num_rows > 0) {
    // Si existe un duplicado, enviar un mensaje de error a la página de clientes
    echo "<script>
            window.location.href='clientes.php';
            localStorage.setItem('error_message', 'El RFC, correo, número de cuenta, teléfono o contacto extra ya están registrados para otro cliente.');
          </script>";
} else {
    // Extraer el primer apellido
    $primer_apellido = explode(' ', trim($apellidos))[0];

    // Generar un código automático basado en el conteo actual de clientes
    $sql_count = "SELECT COUNT(*) AS total FROM clientes";
    $result_count = $conn->query($sql_count);
    $row_count = $result_count->fetch_assoc();
    $codigo_automatico = str_pad($row_count['total'] + 1, 3, '0', STR_PAD_LEFT); 

    // Crear el id_cliente concatenando el primer apellido y el código automático
    $id_cliente = strtoupper($primer_apellido) . $codigo_automatico;

    // Insertar los datos en la base de datos
    $sql_insert = "INSERT INTO clientes (id_cliente, nombre, apellidos, direccion, telefono, correo, RFC, codigo_postal, num_cuenta, contactos_extra, mascotas) 
                   VALUES ('$id_cliente', '$nombre', '$apellidos', '$direccion', '$telefono', '$correo', '$RFC', '$codigo_postal', '$num_cuenta', '$contactos_extra', '$mascotas')";

    if ($conn->query($sql_insert) === TRUE) {
        // Redirigir a la página de clientes con mensaje de éxito
        echo "<script>
                window.location.href='clientes.php';
                localStorage.setItem('success_message', 'El cliente ha sido guardado correctamente.');
              </script>";
    } else {
        echo "Error: " . $sql_insert . "<br>" . $conn->error;
    }
}

// Cerrar la conexión
$conn->close();
?>
