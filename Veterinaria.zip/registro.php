<?php
session_start();
if (isset($_SESSION['usuario_id'])) {
    header("Location: inicio.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Mr. Firu Lays</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.css"
    />
    <link rel="stylesheet" href="./style.css" />
  </head>
  <body>
    <!-- partial:index.partial.html -->
    <div id="login-page">
      <div class="login">
        <h2 class="login-title2">
          <img
            src="../Veterinaria/assets/imgs/veterinario.png"
            alt="Mr.Firulays"
            style="width: 60%; height: 14%; margin: 2px; padding: 12px"
          />
          <span class="red">Mr</span>
          <span class="orange">.</span>
          <span class="blue">Firu</span>
          <span class="yellow">lays</span>
        </h2>
        <form action="config/login.php" method="POST"></form>
        <h2 class="login-title">Registro</h2>
        <p class="notice">
          Por favor, ingresa tus datos para acceder al sistema
        </p>
        
        <form class="form-login">
          <label for="email">Correo</label>
          <div class="input-email">
            
            <input
              type="email"
              name="email"
              placeholder="Ingresa tu correo"
              required
            />
          </div>
          <label for="user"></label>
          <div class="">
            
            
          </div>
          <br>
          <label for="password">Contraseña</label>
          <div class="input-password">
            
            <input
              type="password"
              name="password"
              placeholder="Contraseña"
              required
            />
          </div>

          <label for="password">Confirma tu contraseña</label>
          <div class="input-password">
            
            <input
              type="password"
              name="password"
              placeholder="Confirma tu contraseña"
              required
            />
          </div>
          <div class="checkbox">
            <label for="remember">

          </div>
          <button type="submit">
            <i class="fas fa-door-open"></i> Registrar</button>
        </form>
        
        

      </div>
      <div class="background">
        <div class="cardBox2">
          <div class="card2">
            <h1>
              <div class="banner">
                <img
                  src="../Veterinaria/assets/imgs/perro.png"
                  alt="Mr.Firulays"
                  style="width: 14%; height: 14%"
                />
                <span class="red">Mr</span>
                <span class="orange">.</span>
                <span class="blue">Firu</span>
                <span class="yellow">lays</span>
                <span class="green"></span>
                <span class="pink"></span>
              </div>
              <div class="banner2">
                <span class="green">Bienvenido</span>
                <span class="blue"></span> <span class="yellow"></span>
                <span class="green"></span>
              </div>
            </h1>
          </div>
        </div>
      </div>
    </div>
    <!-- partial -->
  </body>
</html>
